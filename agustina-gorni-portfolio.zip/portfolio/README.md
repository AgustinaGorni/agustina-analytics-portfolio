# Agustina Gorni — Analytics portfolio

A static site (plain HTML/CSS, no build step) built for GitHub Pages.

## What's in here

```
index.html                          → main page (about, case studies, experience, certs, contact)
cases/ecommerce-funnel.html         → Case study 01: ecommerce funnel drop-off
assets/style.css                    → shared styles
assets/funnel-chart.png             → funnel chart used in the case study
downloads/Tracking_Plan_..._EN.docx → downloadable tracking plan referenced in the case study
```

## How to publish it on GitHub Pages (no coding needed)

1. **Create a repository.** Go to [github.com/new](https://github.com/new). Name it whatever you like — a common convention is `your-username.github.io` if you want it to be your main site, or something like `analytics-portfolio` if you want it as a project site (the URL will then be `your-username.github.io/analytics-portfolio`).
2. **Upload these files.** On the repo's main page, click "Add file" → "Upload files", then drag in everything from this folder (keep the folder structure: `index.html` at the root, `assets/`, `cases/`, and `downloads/` as subfolders).
3. **Commit.** Scroll down and click "Commit changes".
4. **Turn on Pages.** Go to the repo's Settings → Pages (left sidebar). Under "Build and deployment", set Source to "Deploy from a branch", branch `main`, folder `/ (root)`. Save.
5. **Wait ~1 minute**, then refresh — GitHub will show you the live URL (something like `https://your-username.github.io/analytics-portfolio/`).

## Updating it later

Any time you want to change text or add a case study: edit the file directly on GitHub (click the pencil icon on the file) or re-upload it. Pages redeploys automatically within a minute of every commit.

## Adding case study 02

Duplicate `cases/ecommerce-funnel.html` as `cases/case-02.html`, update the content, then edit the "upcoming" card in `index.html` (`<div class="case-card upcoming">`) to point to it and drop the `upcoming` class so it looks live.

## Embedding the Power BI dashboard later

Once the Power BI report is published ("Publish to web" from Power BI), you'll get an `<iframe>` embed snippet. Paste it inside the "Dashboard" section of `cases/ecommerce-funnel.html` (it currently just says "in progress").

## Notes

- Fonts (Space Grotesk, Inter, IBM Plex Mono) load from Google Fonts via the `<link>` in `style.css` — this works fine on GitHub Pages, no local font files needed.
- All content is built on public datasets only — no client or employer data.
